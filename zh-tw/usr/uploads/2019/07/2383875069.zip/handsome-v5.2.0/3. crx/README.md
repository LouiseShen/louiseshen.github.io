## 配合handsomev5.2.0及其以上版本才可以正常使用

开发笔记： https://www.ihewro.com/archives/940/

功能介绍：https://handsome.ihewro.com/#/crx

